const btn= document.getElementById("img-x")
const divmsg= document.getElementById("div-devloper")
const namedev= document.getElementById("namedevloper")

function functionanimation(){
    document.getElementById("img-x").style.display="block";
    document.getElementById("div-devloper").style.display="block";
    document.getElementById("namedevloper").style.display="block";
}

function functiondisplayAllElements(){
    document.getElementById("img-x").style.display="none";
    document.getElementById("div-devloper").style.display="none";
    document.getElementById("namedevloper").style.display="none";
}